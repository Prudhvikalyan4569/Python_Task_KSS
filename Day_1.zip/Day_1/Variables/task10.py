# Store a number and print its cube

num = 5

cube = num ** 3

print("Cube =", cube)
