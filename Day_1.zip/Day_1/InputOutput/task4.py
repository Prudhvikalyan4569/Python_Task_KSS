# Take a sentence as input and print it in uppercase


sentence = input("Enter a sentence: ")
print("Uppercase:", sentence.upper())
