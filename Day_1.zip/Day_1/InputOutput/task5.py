# Write a program that takes 3 numbers as input and prints their average

num1 = int(input("Enter first number:"))
num2 = int(input("Enter second number:"))
num3 = int(input("Enter third number:"))

average = (num1 + num2 + num3) / 3
print("Average is:", average)

